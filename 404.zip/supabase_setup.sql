-- 1. Create Dishes Table
CREATE TABLE dishes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  emoji TEXT DEFAULT '🥗',
  category TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. Create Roles Table (Staff Management)
CREATE TABLE roles (
  phone TEXT PRIMARY KEY,
  role TEXT CHECK (role IN ('admin', 'waiter')),
  added_at TIMESTAMPTZ DEFAULT now()
);

-- 3. Create Guests Table
CREATE TABLE guests (
  phone TEXT PRIMARY KEY,
  id TEXT, -- For convenience matching phone
  name TEXT,
  members INTEGER,
  dishes JSONB DEFAULT '[]',
  completed BOOLEAN DEFAULT false,
  checked_in BOOLEAN DEFAULT false,
  assigned_waiter TEXT REFERENCES roles(phone),
  table_number TEXT,
  status TEXT DEFAULT 'active',
  registered_at TIMESTAMPTZ DEFAULT now(),
  allocated_at TIMESTAMPTZ,
  outfit_url TEXT
);

-- 4. Enable Row Level Security (RLS) - Basic "Allow All" for now like your test rules
ALTER TABLE dishes ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE guests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow All" ON dishes FOR ALL USING (true);
CREATE POLICY "Allow All" ON roles FOR ALL USING (true);
CREATE POLICY "Allow All" ON guests FOR ALL USING (true);
