import * as dbService from '../supabase-service.js';

export function initWaiterDashboard(showScreen, showToast, currentUser) {
    showScreen('screen-waiter');

    dbService.listenToAssignedGuests(currentUser.phoneNumber, (guests) => {
        renderWaiterQueue(guests);
    });
}

function renderWaiterQueue(guests) {
    const container = document.getElementById('waiter-queue');
    if (!container) return;

    if (!guests || guests.length === 0) {
        container.innerHTML = '<p class="text-center p-8 italic text-sm text-text-mid">No guests assigned yet. 🌸</p>';
        return;
    }

    container.innerHTML = guests.map(g => `
        <div class="premium-card stagger-in mb-4">
            <div class="flex justify-between items-start mb-2">
                <div>
                    <h4 class="font-bold text-lg">${g.name}</h4>
                    <p class="text-xs text-gold font-bold">TABLE ${g.table_number || '??'}</p>
                </div>
                <span class="status-badge ${getStatusClass(g.status)}">${g.status}</span>
            </div>
            
            <div class="text-xs text-text-mid mb-4">
                <p>📞 ${g.phone}</p>
                <p>👥 ${g.members} members</p>
                <p class="mt-2 font-bold text-brown-warm text-[10px] uppercase">Dishes: ${(g.dishes || []).join(', ')}</p>
            </div>

            <div class="flex gap-2">
                <button onclick="updateStatus('${g.phone}', 'active')" class="btn-gold flex-1 text-[10px] py-2">Active</button>
                <button onclick="updateStatus('${g.phone}', 'hold')" class="btn-gold flex-1 text-[10px] py-2 opacity-70">Hold</button>
                <button onclick="updateStatus('${g.phone}', 'served')" class="btn-gold flex-1 text-[10px] py-2 bg-green-700 border-none">Served</button>
            </div>
        </div>
    `).join('');
}

function getStatusClass(status) {
    switch (status) {
        case 'active': return 'bg-gold-light text-brown-deep';
        case 'hold': return 'bg-yellow-100 text-yellow-800';
        case 'served': return 'bg-green-100 text-green-800';
        default: return 'bg-gray-100';
    }
}

window.updateStatus = async function (phone, status) {
    await dbService.updateGuestStatus(phone, status);
};

window.checkInGuest = async function () {
    const phone = document.getElementById('checkin-phone').value.trim();
    if (!phone) return;

    const guest = await dbService.getGuest(phone);
    if (!guest) {
        document.getElementById('checkin-result').innerHTML = '<p class="text-red-500 p-4 text-sm font-bold">Guest not found!</p>';
        return;
    }

    const myRole = await dbService.getUserRole(localStorage.getItem('user_phone'));
    if (myRole === 'admin') {
        window.openAllocationUI(guest.phone);
    } else {
        document.getElementById('checkin-result').innerHTML = `
            <div class="p-4 bg-ivory rounded mt-4 border border-cream shadow-sm">
                <p class="font-bold">${guest.name}</p>
                <p class="text-xs mt-1">Status: <span class="uppercase font-bold">${guest.status}</span></p>
                <p class="text-xs">Table: ${guest.table_number || 'Not assigned'}</p>
            </div>
        `;
    }
}
