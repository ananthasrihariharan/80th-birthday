import * as dbService from '../supabase-service.js';

export function initGuestFlow(showScreen, showToast, currentUser) {
    checkGuestStatus(showScreen, currentUser);
}

async function checkGuestStatus(showScreen, currentUser) {
    const guestData = await dbService.getGuest(currentUser.phoneNumber);
    if (guestData && guestData.completed) {
        showGuestDashboard(guestData, currentUser, showScreen);
    } else {
        showGuestForm(showScreen, currentUser);
    }
}

function showGuestForm(showScreen, currentUser) {
    showScreen('screen-guest-form');
    renderDishSelection();
}

function showGuestDashboard(guest, user, showScreen) {
    showScreen('screen-guest-dashboard');
    document.getElementById('display-name').textContent = guest.name;
    document.getElementById('display-count').textContent = guest.members;
    generateQR(user.phoneNumber);
}

function generateQR(phone) {
    const container = document.getElementById('qrcode');
    if (!container) return;
    container.innerHTML = '';
    new QRCode(container, {
        text: JSON.stringify({ phone: phone, type: 'entry' }),
        width: 180, height: 180,
        colorDark: "#1E0F05", colorLight: "#FAF7F0"
    });
}

function renderDishSelection() {
    const container = document.getElementById('dishes-container');
    if (!container) return;

    dbService.listenToDishes((dishes) => {
        if (!dishes.length) {
            container.innerHTML = '<p class="text-center p-4 italic">The menu is being curated with love... 🌸</p>';
            return;
        }

        const categories = dishes.reduce((acc, d) => {
            const cat = d.category || 'Other';
            if (!acc[cat]) acc[cat] = [];
            acc[cat].push(d);
            return acc;
        }, {});

        container.innerHTML = Object.entries(categories).map(([cat, items]) => `
            <div class="mb-6">
                <h4 class="category-label mb-3 text-gold text-xs tracking-widest uppercase font-bold">${cat}</h4>
                <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    ${items.map(d => `
                        <div class="dish-chip premium-card p-3 cursor-pointer" data-id="${d.name}" onclick="this.classList.toggle('selected')">
                            <span class="text-2xl">${d.emoji || '🥗'}</span>
                            <span class="text-sm font-semibold block mt-1">${d.name}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    });
}

window.submitGuestForm = async function (phone, onComplete, showToast, setLoading) {
    const name = document.getElementById('guest-name').value.trim();
    const count = parseInt(document.getElementById('guest-count').value);
    const selected = [...document.querySelectorAll('.dish-chip.selected')].map(el => el.dataset.id);

    if (!name || isNaN(count)) {
        showToast('Please fill in your details 🌸', 'error');
        return;
    }

    setLoading(true);
    try {
        await dbService.saveGuest(phone, {
            name,
            members: count,
            dishes: selected,
            completed: true
        });
        showToast('Successfully registered! ✨', 'success');
        onComplete();
    } catch (e) {
        showToast('Registration failed 🙏', 'error');
    }
    setLoading(false);
};
